from sqlalchemy import Column, Integer, String, SMALLINT, BOOLEAN
from database import Base, engine


class ToDo(Base):
    __tablename__ = 'todo'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(50), default="", nullable=False)
    status = Column(SMALLINT, default=0, nullable=False)
    deleted = Column(BOOLEAN, default=False, nullable=False)

    def __init__(self, name=None, status=None):
        self.name = name
        self.status = status

    def __repr__(self):
        return '<ToDo %r>' % (self.name)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "status": self.status,
            "deleted": self.deleted
        }


def init_db():
    Base.metadata.create_all(bind=engine)


if __name__ == '__main__':
    init_db()
