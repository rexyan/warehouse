from flask import Flask, request, jsonify
from database import db_session
from models import ToDo

app = Flask(__name__)


@app.teardown_appcontext
def shutdown_session(exception=None):
    db_session.remove()


@app.route('/todo', methods=["POST"])
def create_todo():
    # 接收参数
    params = request.json
    # 判断参数是否存在
    if params:
        name = params.get("name")
        todo = ToDo(name=name, status=0)
        db_session.add(todo)
        db_session.commit()
        return {"status": 1, "message": "success"}
    else:
        return {"status": 1, "message": "params error"}, 401


@app.route('/todo/', methods=["DELETE"])
@app.route('/todo/<string:todo_id>', methods=["DELETE"])
def delete_todo(todo_id=None):
    try:
        if todo_id:
            rows = db_session.query(ToDo).filter(ToDo.id == todo_id).update({"deleted": True})
        else:
            rows = db_session.query(ToDo).update({"deleted": True})
        if not rows:
            return {"status": 0, "message": "delete error"}, 401
        db_session.commit()
    except Exception as e:
        return {"status": 0, "message": f"delete error: {e}"}, 401
    return {"status": 1, "message": "success"}


@app.route('/todo/<string:todo_id>', methods=["PUT"])
def update_todo(todo_id):
    data = {}
    # 接收参数
    params = request.json
    # 判断参数是否存在
    if params:
        if params.get("status") is not None:
            data.update({"status": bool(params.get("status"))})
        if params.get("name") is not None:
            data.update({"name": params.get("name")})
        try:
            rows = db_session.query(ToDo).filter(ToDo.id == todo_id, ToDo.deleted != True).update(data)
            if not rows:
                return {"status": 0, "message": f"update error"}, 401
            db_session.commit()
        except Exception as e:
            return {"status": 0, "message": f"update error: {e}"}, 401
        return {"status": 1, "message": "success"}
    else:
        return {"status": 1, "message": "params error"}, 401


@app.route('/todo/', methods=["GET"])
@app.route('/todo/<string:todo_id>', methods=["GET"])
def get_todo(todo_id=None):
    if todo_id:
        todo = db_session.query(ToDo).filter(ToDo.id == todo_id, ToDo.deleted == False).all()
    else:
        todo = db_session.query(ToDo).filter(ToDo.deleted == False).all()
    return jsonify([td.to_dict() for td in todo])


if __name__ == '__main__':
    app.run()
