SQLALCHEMY_DATABASE_URI = "sqlite:///oa.db"
SQLALCHEMY_TRACK_MODIFICATIONS = False
SECRET_KEY = 'your secret key for flask'


###############################################
# 飞书机器人相关
###############################################
FEISHU_VERIFICATION_TOKEN = ''
FEISHU_BOT_APP_ID = ''
FEISHU_BOT_APP_SECRET = ''


###############################################
# 易快报相关配置项
###############################################
EKUAIBAO_HOST = ''
EKUAIBAO_CORP_ID = ''
EKUAIBAO_APP_KEY = ''
EKUAIBAO_APP_SECRET = ''


###############################################
# 在途相关配置项
###############################################
ZTRIP_HOST = ''
ZTRIP_CLIENT_ID = ''
ZTRIP_CLIENT_SECRET = ''
