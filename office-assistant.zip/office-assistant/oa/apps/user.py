from oa import models
from oa.api import ApiBlueprint
from oa.apps.schema import strip_str, nullable_str
from swagger import doc
from voluptuous import Required

bp = ApiBlueprint("user", __name__, url_prefix="/api/v1")


@bp.post("/")
@doc.summary("用户创建", group="用户")
@doc.response(200, {"id": int, "name": str}, description="返回新增用户 ID 及 Name 信息")
@doc.consumes({
    Required("name"): strip_str,
    Required("phone"): strip_str,
    "age": int,
    "gender": bool,
    "other": {
            "address": strip_str,
            "email": strip_str
        }
    },
    location="body")
def create_user(*args, **kwargs):
    pass


@bp.delete("/<string:u_id>")
@doc.summary("删除用户", group="用户")
@doc.response(200, {"status": int, "msg": str}, description="返回操作状态信息")
@doc.consumes({Required("u_id"): strip_str})
def delete_user(*args, **kwargs):
    pass


@bp.put("/")
@doc.summary("修改用户", group="用户")
@doc.response(200, models.User, description="返回字段为 User 实体字段")
@doc.consumes({
    "name": strip_str,
    "phone": strip_str,
    "age": int,
    "gender": bool,
    "other": {
        "address": nullable_str,
        "email": nullable_str}
})
def update_user(*args, **kwargs):
    pass


@bp.get("/")
@bp.get("/<string:u_id>")
@doc.summary("查询用户", group="用户")
@doc.response(200, models.User, description="返回字段为 User 实体字段")
@doc.consumes({"u_id": strip_str})
def get_user(*args, **kwargs):
    pass
