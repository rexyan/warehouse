import datetime

from voluptuous import Invalid, ValueInvalid


def strip_str(value):
    if value is None:
        raise ValueInvalid("参数不能为空")
    return str(value).strip()


def nullable_str(value):
    if value is None:
        return None
    return str(value).strip()


def bool_str(value):
    if not value:
        return None
    return str(value) in ["1", "yes", "true"]


def v_datetime(v):
    try:
        return datetime.datetime.strptime(v, "%Y-%m-%d %H:%M:%S")
    except Exception:
        raise Invalid(f"{v} is not a valid datetime")


def v_date(v):
    try:
        return datetime.datetime.strptime(v, "%Y%m")
    except Exception:
        raise Invalid(f"{v} is not a valid date")
