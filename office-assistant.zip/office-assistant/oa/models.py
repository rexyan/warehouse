from __future__ import print_function

from sqlalchemy.ext.declarative import declarative_base

from .enums import UserStatus
from .globals import Model
import sqlalchemy as sa

from .utils import to_decimal

Base = declarative_base()


class User(Model):
    """
    职工信息，从易快报同步
    """

    __tablename__ = "users"
    id = sa.Column(sa.BigInteger, primary_key=True)
    feishu_id = sa.Column(sa.String(20))  # 用于发送飞书通知

    name = sa.Column(sa.String(50))  # 从易快报同步
    email = sa.Column(sa.String(120))  # 从易快报同步
    mobile = sa.Column(sa.String(20))  # 从易快报同步
    ekuaibao_id = sa.Column(sa.String(60))  # 易快报的 UserID/StaffID
    ekuaibao_uid = sa.Column(sa.String(20))  # 第三方用户ID，可以是我们自己的用户ID
    ekuaibao_code = sa.Column(sa.String(20))  # 易快报员工工号
    active = sa.Column(sa.BOOLEAN, default=True)
    # 在途员工编码，企业内应保证唯一。如果员工已经注册，则从在途同步，否则用 ekuaibao_id
    ztrip_code = sa.Column(sa.String(30))  # 默认是 f"cy{user.id}"
    ztrip_rank = sa.Column(sa.String(50))  # 在途职工职级编码
    status = sa.Column(sa.Enum(UserStatus, native_enum=False), default=UserStatus.VALID)

    def __repr__(self):
        return "<User %r>" % self.name

    def get_ztrip_code(self):
        # return self.ztrip_code or f"cy{self.id}"
        return self.ztrip_code or self.ekuaibao_code


class Department(Model):
    """
    部门信息，从易快报同步
    """

    name = sa.Column(sa.String(20))
    code = sa.Column(sa.String(20))  # 同步自易快报 dep.code
    dep_id = sa.Column(sa.String(60))  # 同步自易快报 dep.id, 同步到在途的 code
    parent_dep_id = sa.Column(sa.String(60))
    active = sa.Column(sa.BOOLEAN, default=True)


class UserDepartment(Model):
    user_id = sa.Column(sa.BigInteger)
    dep_id = sa.Column(sa.String(60))  #
    is_default = sa.Column(sa.BOOLEAN, default=False)


class EKuaibaoTicket(Model):
    user_id = sa.Column(sa.BigInteger)
    title = sa.Column(sa.String(200))  # 易快报后台没有限制，但是再多就写小作文了。。。
    remark = sa.Column(sa.String(200))  # 同步自 remark 字段
    code = sa.Column(sa.String(20))
    ticket_type = sa.Column(sa.String(20))  # 单据类型，同步自易快报 type 字段
    # ticket_data_type = sa.Column(sa.String(20))  # 单据数据类型，同步自易快报dataType
    ekuaibao_ticket_id = sa.Column(sa.String(20))  # 易快报ticket id
    ekuaibao_user_id = sa.Column(sa.String(60))  # 对应User.ekuaibao_id
    ekuaibao_specification_id = sa.Column(sa.String(60))  # 申请单模板ID
    ekuaibao_state = sa.Column(sa.String(20))  # 同步自易快报状态
    project_name = sa.Column(sa.String(100))  # 项目名
    project_id = sa.Column(sa.String(20))  # 项目ID
    project_code = sa.Column(sa.String(60))  # 项目编号
    ekuaibao_submit_date = sa.Column(sa.DateTime)
    ekuaibao_requisition_date = sa.Column(sa.DateTime)
    ekuaibao_pay_time = sa.Column(sa.DateTime)  # 申请单审批通过时间，报销单付款时间


class EKuaibaoTicketTrips(Model):
    ticket_id = sa.Column(sa.BigInteger)  # 易快报单据ID
    index = sa.Column(sa.Integer, default=1)  # 行程顺序
    amount = sa.Column(sa.DECIMAL(10, 2), default=to_decimal(0))
    # 易快报可选：taxl-打车 hotel-酒店 aircraft或者flight-飞机 train-火车
    # 在途可选：FLIGHT(飞机)/ TRAIN(火车)/ SHIP(轮船)/TAXI(汽车)/ UNKNOW(未定) /HOTEL(酒店)
    trip_type = sa.Column(sa.String(40))  # 行程类型，同步自易快报 trip_type_id, 同步到在途系统。现在默认都是不限，这里只做数据记录
    trip_id = sa.Column(sa.String(20))
    trip_date = sa.Column(sa.DateTime)  # 易快报拿到的是时间戳，在途需要的是 2020-01-01 的字符串
    to_city_id = sa.Column(sa.BigInteger)  # 对应 City.id
    to_city_name = sa.Column(sa.String(80))  # 同步自 ticket 完整路径
    from_city_id = sa.Column(sa.BigInteger)  # 对应 City.id
    from_city_name = sa.Column(sa.String(80))  # 对应 ticket 完整路径


class EKuaibaoTicketTravelers(Model):
    ticket_id = sa.Column(sa.BigInteger)
    ekuaibao_id = sa.Column(sa.String(60))  # 同步自易快报 ticket travelers.id
    user_id = sa.Column(sa.BigInteger)


class City(Model):
    """
    城市信息，同步自易快报，映射到在途的城市ID，自己不维护层级关系
    """

    name = sa.Column(sa.String(20))
    ekuaibao_code = sa.Column(sa.String(60))
    ekuaibao_id = sa.Column(sa.String(15))  # 同步自易快报 id
    ekuaibao_parent_id = sa.Column(sa.String(15))  # 同步自易快报 parent_id
    ztrip_id = sa.Column(sa.String(20))  # 同步到在途
