from flask import g
from flask_caching import Cache
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from .db import ModelClass, Query
from sqlalchemy.orm import Session
from typing import TYPE_CHECKING

db = SQLAlchemy(model_class=ModelClass, query_class=Query)


session: Session = db.session

if TYPE_CHECKING:
    from .models import User

    class Model(ModelClass):
        pass


else:
    Model = db.Model


migrate = Migrate(compare_type=True)
# 缓存默认20秒
cache = Cache(config={"CACHE_TYPE": "simple", "CACHE_DEFAULT_TIMEOUT": 20})


def current_user() -> "User":
    return g.user  # type: ignore
