import concurrent.futures
import dataclasses
import sys

import shlex
import subprocess
from fabric import Connection
from invoke import task

SITE_ROOT = "/var/www/cyclone-oa"


def exists(c, path):
    cmd = f"stat $(echo {path})"
    return c.run(cmd, warn=True, hide=True).ok


def local(command):
    args = shlex.split(command)
    shell = False
    if sys.platform == 'win32':
        shell = True
    p = subprocess.check_output(args, shell=shell).strip()
    return p.decode()


def deploy(c, filename, migrate=True, beat=True):
    if not exists(c, SITE_ROOT):
        c.run(f"mkdir {SITE_ROOT}")
        c.run(f"chmod 775 {SITE_ROOT}")
    with c.cd(SITE_ROOT):

        c.put("dist/%s" % filename, "/tmp/%s" % filename)

        if not exists(c, f"venv"):
            c.run("python3 -m venv venv")
        c.run(
            "sudo -H %s/venv/bin/pip install -U /tmp/%s "
            "-i https://mirrors.aliyun.com/pypi/simple" % (SITE_ROOT, filename)
        )
        c.run("rm -r /tmp/%s" % filename)
        env = f'FLASK_APP="oa.app:create_app()" APP_SETTINGS={SITE_ROOT}/config.yaml'

        if migrate:
            if not exists(c, "migrations"):
                c.run("{} venv/bin/flask db init".format(env))
            c.run("{} venv/bin/flask db migrate".format(env))
            c.run("{} venv/bin/flask db upgrade".format(env))
        c.run("sudo supervisorctl restart oa:")
        # if beat:
        #     c.run("sudo supervisorctl restart sven_beat")
        # c.run("sudo find . -exec chown :www-data {} +")
        # c.run("sudo find . -exec chmod g+wx {} +")


@dataclasses.dataclass
class Host:
    hostname: str
    filename: str
    migrate: bool
    beat: bool


def d(host: Host):
    deploy(Connection(host.hostname), host.filename, host.migrate, host.beat)


def pack():
    local("poetry build -f wheel")
    return local("ls dist")


@task
def prod(c):
    filename = pack()
    hosts = [Host("prod-1-cyclone", filename, True, True,)]
    with concurrent.futures.ThreadPoolExecutor() as executor:
        for _ in executor.map(d, hosts):
            pass



@task
def staging(c):
    filename = pack()
    host = "dev-cyclone"
    d(Host(host, filename, True, True))
