# 搜索引擎地址
SEARCH_ENGINE_URL = "https://google.com"

# 查询框 xpath 地址
SEARCH_ELE_XPATH = '//*[@id="tsf"]/div[2]/div/div[1]/div/div[1]/input'

# 查询按钮 xpath
SEARCH_BUTTON_XPATH = '//*[@id="tsf"]/div[2]/div/div[3]/center/input[1]'

# 目标位置
TARGET_RESULT_XPATH = '//a[@href="https://www.huifu.com/about-company/"]'

# 查询指定关键字
SEARCH_KEY= "汇付"
