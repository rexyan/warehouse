"""
流程: 打开 chrome，并且打开 google，输入 "汇付" 进行搜索。并对，指定页面进行点击
"""
from automagica_demo.utils.operate import OperateUtils
from automagica_demo.settings import (
    SEARCH_ENGINE_URL, SEARCH_KEY, SEARCH_ELE_XPATH, SEARCH_BUTTON_XPATH, TARGET_RESULT_XPATH
)


def main():
    # 打开浏览器，并打开搜索引擎地址
    op = OperateUtils()
    browser = op.open_url(SEARCH_ENGINE_URL)

    # 寻找搜索框，并输入查找文本
    element = op.find_element_by_xpath(browser, SEARCH_ELE_XPATH)
    op.input_content(element, SEARCH_KEY)

    # 搜索
    op.find_element_and_click(browser, SEARCH_BUTTON_XPATH)

    # 点击指定条目
    op.find_element_and_click(browser, TARGET_RESULT_XPATH)


if __name__ == "__main__":
    main()
