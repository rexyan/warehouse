"""
对 chrome 打开关闭操作
"""
from automagica import ChromeBrowser


class ChromeUtils():
    @staticmethod
    def open_chrome():
        """
        打开 chrome
        :return:
        """
        browser = ChromeBrowser()
        return browser

    @staticmethod
    def close_chrome(browser: ChromeBrowser):
        """
        关闭 chrome
        :param browser:
        :return:
        """
        browser.close()
