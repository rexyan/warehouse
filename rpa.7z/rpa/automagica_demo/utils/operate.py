from automagica_demo.utils.chrome import *


class OperateUtils():
    def open_url(self, url: str):
        """
        打开指定地址
        :param url:
        :return:
        """
        browser = ChromeUtils.open_chrome()
        browser.get(url)
        return browser

    def find_element_by_name(self, browser: ChromeBrowser, name: str):
        """
        根据名称寻找指定元素
        :param name:
        :param browser:
        :return:
        """
        element = browser.find_element_by_name(name)
        return element

    def find_element_by_xpath(self, browser: ChromeBrowser, xpath: str):
        """
        根据 xpath 寻找指定元素
        :param browser:
        :param xpath:
        :return:
        """
        element = browser.find_element_by_xpath(xpath)
        return element

    def input_content(self, element, content: str):
        """
        指定元素输入内容
        :param element:
        :param content:
        :return:
        """
        element.send_keys(content)

    def click_event(self, element):
        """
        点击某元素
        :param element:
        :return:
        """
        element.click()

    def find_element_and_click(self, browser, xpath):
        """
        查找指定位置，并进行点击动作
        :param op:
        :param browser:
        :param xpath:
        :return:
        """
        element = self.find_element_by_xpath(browser, xpath)
        self.click_event(element)